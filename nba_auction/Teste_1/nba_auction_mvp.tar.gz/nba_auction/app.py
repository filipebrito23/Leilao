import pandas as pd
import streamlit as st
from sqlalchemy import text
from db import engine, init_db
from auction import submit_bid, close_expired_bids

st.set_page_config(page_title="Leilão NBA Fantasy", layout="wide")
init_db()
close_expired_bids()

st.title("Leilão NBA Fantasy")
st.caption("MVP de leilão com propostas ativas por jogador, controle de cap e renovação.")

tab1, tab2, tab3 = st.tabs(["Propostas ativas", "Nova proposta", "Cap dos times"])

with tab1:
    position = st.selectbox("Posição", ["Todas", "PG", "PGSG", "SG", "SGSF", "SF", "SFPF", "PF", "PFC", "C"])

    query = """
    SELECT
        p.player_id,
        p.player_name,
        p.position,
        owner.team_name AS dono,
        t.team_name AS time_ativo,
        ps.active_amount AS proposta_ativa,
        ps.active_years AS anos,
        ps.active_at,
        ps.expires_at,
        ps.status
    FROM players p
    LEFT JOIN teams owner ON owner.team_id = p.owner_team_id
    LEFT JOIN player_state ps ON ps.player_id = p.player_id
    LEFT JOIN teams t ON t.team_id = ps.active_team_id
    """
    params = {}
    if position != "Todas":
        query += " WHERE p.position = :position"
        params["position"] = position
    query += " ORDER BY p.position, p.player_name"

    with engine.begin() as conn:
        rows = conn.execute(text(query), params).mappings().all()

    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

with tab2:
    with engine.begin() as conn:
        players = conn.execute(text("""
            SELECT player_id, player_name || ' (' || position || ')' AS label
            FROM players
            WHERE status = 'OPEN'
            ORDER BY position, player_name
        """)).fetchall()

        teams = conn.execute(text("""
            SELECT team_id, team_name
            FROM teams
            ORDER BY team_name
        """)).fetchall()

    player_map = {label: pid for pid, label in players}
    team_map = {name: tid for tid, name in teams}

    with st.form("bid_form"):
        player_label = st.selectbox("Jogador", list(player_map.keys()) if player_map else ["Sem jogadores disponíveis"])
        team_name = st.selectbox("Time", list(team_map.keys()) if team_map else ["Sem times cadastrados"])
        amount = st.number_input("Valor da proposta", min_value=0.0, step=100000.0, format="%.2f")
        years = st.number_input("Anos", min_value=1, max_value=5, step=1)
        submitted = st.form_submit_button("Enviar proposta")

        if submitted:
            if not player_map or not team_map:
                st.error("Base não carregada. Importe a planilha primeiro.")
            else:
                ok, msg = submit_bid(
                    player_id=player_map[player_label],
                    team_id=team_map[team_name],
                    amount=amount,
                    years=years
                )
                if ok:
                    st.success(msg)
                else:
                    st.error(msg)

with tab3:
    with engine.begin() as conn:
        rows = conn.execute(text("""
            SELECT
                t.team_name,
                t.cap_limit,
                COALESCE(SUM(CASE WHEN b.is_active = 1 AND b.is_valid = 1 AND b.is_renewal = 0 THEN b.amount ELSE 0 END), 0) AS used_cap,
                t.cap_limit - COALESCE(SUM(CASE WHEN b.is_active = 1 AND b.is_valid = 1 AND b.is_renewal = 0 THEN b.amount ELSE 0 END), 0) AS available_cap
            FROM teams t
            LEFT JOIN bids b ON b.team_id = t.team_id
            GROUP BY t.team_id, t.team_name, t.cap_limit
            ORDER BY available_cap DESC
        """)).mappings().all()

    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
