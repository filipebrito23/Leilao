from datetime import datetime, timedelta
from sqlalchemy import text
from db import engine


def get_team_cap_status(conn, team_id):
    cap_limit = conn.execute(
        text("SELECT cap_limit FROM teams WHERE team_id = :team_id"),
        {"team_id": team_id}
    ).scalar()

    used = conn.execute(text("""
        SELECT COALESCE(SUM(b.amount), 0)
        FROM bids b
        WHERE b.team_id = :team_id
          AND b.is_active = 1
          AND b.is_valid = 1
          AND b.is_renewal = 0
    """), {"team_id": team_id}).scalar()

    return float(cap_limit or 0), float(used or 0), float((cap_limit or 0) - (used or 0))


def close_expired_bids():
    now = datetime.utcnow().isoformat()

    with engine.begin() as conn:
        rows = conn.execute(text("""
            SELECT player_id, active_bid_id
            FROM player_state
            WHERE status = 'OPEN'
              AND expires_at IS NOT NULL
              AND expires_at < :now
        """), {"now": now}).fetchall()

        for row in rows:
            conn.execute(text("""
                UPDATE player_state
                SET status = 'CLOSED'
                WHERE player_id = :player_id
            """), {"player_id": row.player_id})

            conn.execute(text("""
                UPDATE players
                SET status = 'CLOSED', closed_at = :now
                WHERE player_id = :player_id
            """), {"player_id": row.player_id, "now": now})


def submit_bid(player_id, team_id, amount, years):
    now = datetime.utcnow()
    expires_at = now + timedelta(hours=24)

    with engine.begin() as conn:
        player = conn.execute(text("""
            SELECT p.player_id, p.owner_team_id, p.status
            FROM players p
            WHERE p.player_id = :player_id
        """), {"player_id": player_id}).mappings().first()

        if not player:
            return False, "Jogador não encontrado."

        if player["status"] != "OPEN":
            return False, "Leilão desse jogador já foi fechado."

        is_renewal = 1 if player["owner_team_id"] == team_id else 0

        _, _, available = get_team_cap_status(conn, team_id)

        current_active = conn.execute(text("""
            SELECT active_bid_id, active_team_id, active_amount
            FROM player_state
            WHERE player_id = :player_id
        """), {"player_id": player_id}).mappings().first()

        released_amount = 0
        if current_active and current_active["active_team_id"] == team_id:
            released_amount = float(current_active["active_amount"] or 0)

        effective_available = available + (0 if is_renewal else released_amount)

        if not is_renewal and amount > effective_available:
            return False, f"Cap insuficiente. Disponível: {effective_available:,.2f}"

        if current_active and current_active["active_bid_id"]:
            conn.execute(text("""
                UPDATE bids
                SET is_active = 0
                WHERE bid_id = :bid_id
            """), {"bid_id": current_active["active_bid_id"]})

        result = conn.execute(text("""
            INSERT INTO bids(player_id, team_id, amount, years, created_at, is_valid, is_active, is_renewal)
            VALUES(:player_id, :team_id, :amount, :years, :created_at, 1, 1, :is_renewal)
        """), {
            "player_id": player_id,
            "team_id": team_id,
            "amount": amount,
            "years": years,
            "created_at": now.isoformat(),
            "is_renewal": is_renewal
        })

        bid_id = result.lastrowid

        conn.execute(text("""
            INSERT INTO player_state(player_id, active_bid_id, active_team_id, active_amount, active_years, active_at, expires_at, status)
            VALUES(:player_id, :bid_id, :team_id, :amount, :years, :active_at, :expires_at, 'OPEN')
            ON CONFLICT(player_id) DO UPDATE SET
                active_bid_id = excluded.active_bid_id,
                active_team_id = excluded.active_team_id,
                active_amount = excluded.active_amount,
                active_years = excluded.active_years,
                active_at = excluded.active_at,
                expires_at = excluded.expires_at,
                status = 'OPEN'
        """), {
            "player_id": player_id,
            "bid_id": bid_id,
            "team_id": team_id,
            "amount": amount,
            "years": years,
            "active_at": now.isoformat(),
            "expires_at": expires_at.isoformat()
        })

        return True, "Proposta registrada com sucesso."
