# MVP - Leilão NBA Fantasy

Este projeto é um MVP em Streamlit para controlar um leilão de jogadores da NBA para fantasy game.

## O que ele faz

- Lê jogadores por posição a partir da planilha `Lista.xlsx`
- Lê a aba `Cap` para cadastrar o limite de cada time
- Mantém histórico de propostas
- Define uma proposta ativa por jogador
- Desconsidera propostas anteriores do mesmo jogador
- Calcula cap consumido por time usando apenas propostas ativas
- Ignora no cap as propostas de renovação quando o time ofertante é o `Dono` do jogador
- Fecha automaticamente uma proposta após 24 horas da proposta ativa

## Estrutura

- `app.py`: interface Streamlit
- `db.py`: criação do banco SQLite
- `import_xlsx.py`: importação da planilha inicial
- `auction.py`: regras do leilão
- `data/auction.db`: banco gerado em runtime

## Como usar

1. Coloque a planilha `Lista.xlsx` na raiz do projeto.
2. Instale as dependências:

```bash
pip install -r requirements.txt
```

3. Rode a importação inicial:

```bash
python import_xlsx.py
```

4. Suba o app:

```bash
streamlit run app.py
```

## Observações

- Este é um MVP com SQLite.
- Para uso com mais usuários e deploy real, o ideal é migrar para Postgres.
- O Streamlit funciona bem como interface multiusuário, desde que o estado real fique no banco, não no `st.session_state`.
